    <?php $__env->startSection('title'); ?>
    تعديل معاملة - ماسترز ستور
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">المصروفات و الإيرادات</h4><span class="text-muted mt-1 tx-13 mr-2 mb-0">/ تعديل
                معاملة ( <?php echo e($account->name); ?> )</span>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-lg-12 col-md-12">

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <button aria-label="Close" class="close" data-dismiss="alert" type="button">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <strong>خطا</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="col-lg-12 margin-tb">
                        <div class="pull-right">
                            <a class="btn btn-primary" href="<?php echo e(route('accounts.index')); ?>">رجوع</a>
                        </div>
                    </div><br>
                    <?php echo Form::model($account,['route' => ['accounts.update' , $account->id], 'method' => 'put']); ?>

                    <div class="row mg-b-20">
                        <div class="parsley-input col-md-6" id="fnWrapper">
                        <?php echo Html::decode(Form::label('username', 'اسم المستخدم : <span class="tx-danger">*</span>')); ?>

                        <?php echo Form::text('username', old('username', $account->username),['class'=>'form-control form-control-sm mg-b-20"
                                           data-parsley-class-handler="#lnWrapper', 'readonly' ]); ?>

                        </div>

                        <div class="col-md-6">
                            <?php echo Html::decode(Form::label('type', 'نوع المعاملة : <span class="tx-danger">*</span>')); ?>

                            <?php echo Form::select('type',  ['ايرادات','مصروفات'],old('type',$account->type), array('placeholder' => 'من فضلك اختر نوع المعاملة',  'class' => 'form-control  nice-select  custom-select' )); ?>

                        </div>
                    </div>
                    <div class="row mg-b-20">
                        <div class="parsley-input col-md-6" id="fnWrapper">
                            <?php echo Html::decode(Form::label('name', 'وصف المعاملة : <span class="tx-danger">*</span>')); ?>

                            <?php echo Form::text('name', old('name', $account->name),['class'=>'form-control form-control-sm mg-b-20"
                                               data-parsley-class-handler="#lnWrapper' ]); ?>

                        </div>
                        <div class="parsley-input col-md-6 mg-t-20 mg-md-t-0" id="lnWrapper">
                            <?php echo Html::decode(Form::label('money_amount', 'قيمة المعاملة : <span class="tx-danger">*</span>')); ?>

                            <?php echo Form::text('money_amount', old('money_amount',$account->money_amount),['class'=>'form-control form-control-sm mg-b-20"
                                               data-parsley-class-handler="#lnWrapper' ]); ?>

                        </div>
                    </div>
                    <div class="row mg-b-20">
                        <div class="parsley-input col-md-6 mg-t-20 mg-md-t-0" id="lnWrapper">
                            <?php echo Html::decode(Form::label('notes', 'الملاحظات : ')); ?>

                            <?php echo Form::textarea('notes', old('notes',$account->notes),['class'=>'form-control form-control-sm mg-b-20"
                                               data-parsley-class-handler="#lnWrapper' ]); ?>

                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                        <?php echo Form::submit('تعديل', ['class' => 'btn btn-main-primary pd-x-20']); ?>

                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>

    <!-- main-content closed -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New Project\masters-store\resources\views/accounts/edit.blade.php ENDPATH**/ ?>